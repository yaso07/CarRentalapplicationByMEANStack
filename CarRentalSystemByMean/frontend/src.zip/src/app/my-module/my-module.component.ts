import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-module',
  templateUrl: './my-module.component.html',
  styleUrls: ['./my-module.component.css']
})
export class MyModuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
