import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MyModuleComponent } from './my-module.component';


@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [MyModuleComponent],
  schemas:[CUSTOM_ELEMENTS_SCHEMA]
})
export class MyModuleModule { }
