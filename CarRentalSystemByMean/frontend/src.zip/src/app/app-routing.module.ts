import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';

import { HomeComponent } from './home/home.component';

import { CarrentalComponent } from './carrental/carrental.component';

import { BookingComponent } from './booking/booking.component';
import { PaymentComponent } from './booking/payment/payment.component';
import { CheckoutdetailsComponent } from './booking/checkoutdetails/checkoutdetails.component';
import { BillingComponent } from './booking/billing/billing.component';
import { AuthorizationGuard } from './guards/authorization.guard';
import { ProfileComponent } from './profile/profile.component';
import { MybookingsComponent } from './mybookings/mybookings.component';
import { AdminComponent } from './admin/admin.component';

const routes: Routes = [
  {
    path: 'car',
    component: CarrentalComponent,
  },
  {
    path: 'home',
    component: HomeComponent,
  },
  {
    path: 'booking/:car',
    component: CheckoutdetailsComponent,
    canActivate: [AuthorizationGuard],
  },
  {
    path: 'booking',
    canActivateChild: [AuthorizationGuard],
    children: [
      {
        path: 'payment/:id',
        component: PaymentComponent,
      },
    ],
  },
  {
    path: 'profile',
    component: ProfileComponent,
    canActivate: [AuthorizationGuard],
  },
  {
    path: 'mybookings',
    component: MybookingsComponent,
    canActivate: [AuthorizationGuard],
  },
  {
       path:'admin',
       component:AdminComponent
  },
  {
    path: '',
    component: HomeComponent,
  },
  {
    path: '**',
    component: HomeComponent,
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
