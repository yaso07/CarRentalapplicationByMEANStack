import { Component } from '@angular/core';
import { CarService } from './services/car.service';
import { UserService } from './services/user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'CarRentalSystem';
  constructor(public carService: CarService,private user:UserService) {

  }
  ngDoCheck()
  {
   

  }
}
