import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { isEmpty } from 'rxjs';

@Injectable({
  providedIn:'any',
})
export class CarService {
  constructor(private http: HttpClient) {
       http.get(this.renturl).subscribe(data=>{
            this.location=JSON.parse(JSON.stringify(data)).location
       })
  }

  url = ' http://localhost:3000/car';
  renturl= 'http://localhost:3000/rentInput';
  rentComponent=true;
  rent:any;
  return:any;
  location="";
  currentcarid:any;

  getcardetails() {
    return this.http.get('http://localhost:3000/car');
  }


  setRentInput(data:any,rentdata:any)
  {
this.location=data.location
if (rentdata == '') {
  return this.http.post(this.renturl,data);
} else {
  return this.http.put(this.renturl + '/' + 1, data);
}



  }
  getRentInput()
  {


         return this.http.get(this.renturl);


  }
  getRentData()
  {
       return this.http.get(this.renturl + '/' + 1);
  }
  delete(id:number)
  {
      console.log(this.http.delete(this.renturl+'/'+id).subscribe(data=>
        {

        }))
        this.rent=''
        this.return=''
        this.location=''
  }

}
