import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable()
export class UserService {
  url = 'http://localhost:3000/user';
  billingUrl = 'http://localhost:3000/billingDetails';
  bookingUrl = 'http://localhost:3000/booking';
  biddingUrl = 'http://localhost:3000/bidding';
  constructor(private http: HttpClient) {}
  userLogged: any;
  currentUserId: any;
  addUser(user: any) {
    console.log(user);
    return this.http.post(this.url, user);
  }
  getUser() {
    return this.http.get(this.url);
  }
  user: any;
  getUserByName(name: any) {
    return this.http.get(this.url + '?username=' + name);
  }
  getUserById() {
    return this.http.get(this.url + '/' + sessionStorage.getItem('id'));
  }

  getUserLogged() {
    return sessionStorage.getItem('name') == null ? false : true;
  }

  updateUserdetails(value: any, id: any) {
    return this.http.patch(this.url + '/' + id, value);
  }

  addBooking(bookingDetails: any) {
    return this.http.post(this.bookingUrl, bookingDetails);
  }
  getBookingDetails() {
    return this.http.get(
      this.bookingUrl + '?userid=' + sessionStorage.getItem('id')
    );
  }
  cancelBooking(bookingId: number) {
    return this.http.delete(this.bookingUrl + '/' + bookingId);
  }
  addBidding(biddingobj: any) {
    return this.http.post(this.biddingUrl, biddingobj);
  }
  getBiddingDetails() {
    return this.http.get(this.biddingUrl);
  }
  biddingValid(id: any, value: any) {
    return this.http.patch(this.biddingUrl + '/' + id, value);
  }
  getBiddingDetailsById(id: any) {
    return this.http.get(this.biddingUrl + '/' + id);
  }
  getBiddingDetailsDesc() {
    return this.http.get('http://localhost:3000/bidding?_sort=id&_order=desc');
  }
}


