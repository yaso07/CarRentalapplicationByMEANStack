import { Injectable } from '@angular/core';

@Injectable()
export class BiddingService {
accepted=false
carid:any
constructor() { }

}
