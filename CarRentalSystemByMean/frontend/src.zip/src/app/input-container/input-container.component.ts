import { Component, EventEmitter, Input, Output, SimpleChanges } from '@angular/core';

import { FormBuilder, FormControl, Validators ,FormGroup} from '@angular/forms';
import { CarService } from '../services/car.service';

import { RentInputFormServiceService } from '../services/rentInputFormService.service';
@Component({
  selector: 'app-input-container',
  templateUrl: './input-container.component.html',
  styleUrls: ['./input-container.component.css'],

})
export class InputContainerComponent {
  constructor(

    public fb: FormBuilder,
    public carService: CarService,

    private rentservice:RentInputFormServiceService
  ) {


  }

  location: any;


  inputform = this.fb.group({
    location: ['', Validators.required],
    rentdate: ['', Validators.required],
    returndate: ['', Validators.required],
  });



  call() {
    console.log('called');
  }
  onsubmit(data: any) {

    console.log("data")

     

         this.carService.getRentInput().subscribe((data) => {
               this.carService
                 .setRentInput(this.inputform.value, data)
                 .subscribe((data) => {});
                 console.log(data);
                 this.rentservice.setRentdata(this.inputform.value);
         });



  }
}
