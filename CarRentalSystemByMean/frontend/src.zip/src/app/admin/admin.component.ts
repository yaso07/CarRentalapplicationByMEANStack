import { Component, OnInit } from '@angular/core';
import { CarService } from '../services/car.service';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css'],
})
export class AdminComponent implements OnInit {
  constructor(private service: CarService,
    private userService:UserService) {}
  ngOnInit() {
    this.service.rentComponent = false;
    this.userService.getBiddingDetailsDesc().subscribe((data)=>{
         this.biddingDetails=data;
         console.log(this.biddingDetails)
    })
  }

  biddingDetails:any
  bidding:any
  biddingid:any
  value={}
  container=false;
  style:any
  selectedBidding(bidding)
  {
    this.container=true
   this.bidding=bidding;
   this.biddingid=bidding.id

  this.style ="background-color"

  }
  accept(id:any)
  {

     this.value={accepted:"yes"}
     this.userService.biddingValid(id,this.value).subscribe();
  }
  reject(id:any)
  {
      this.value = { accepted: 'no' };
      this.userService.biddingValid(id, this.value).subscribe();
  }
}
