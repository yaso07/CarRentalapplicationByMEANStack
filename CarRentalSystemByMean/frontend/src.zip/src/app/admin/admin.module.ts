import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminComponent } from './admin.component';
import { CarService } from '../services/car.service';

@NgModule({
  imports: [
    CommonModule,

  ],
  declarations: [AdminComponent],


})
export class AdminModule {

 

}
