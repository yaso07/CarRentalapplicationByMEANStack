import { Component ,Input} from '@angular/core';

import { CarService } from '../services/car.service';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent {
  image = '/assets/car image.jpg';
  constructor(private carService: CarService,private router:Router,private user:UserService) {


  }
  ngOnInit()
  { 
  }
  ngDoCheck() {
    if (this.router.url.includes('booking')) {
      this.carService.rentComponent = false;
    } else {
      this.carService.rentComponent = true;
    }
  }


}
