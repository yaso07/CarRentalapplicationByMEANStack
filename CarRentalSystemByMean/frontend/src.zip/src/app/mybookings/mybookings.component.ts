import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';
import { CarService } from '../services/car.service';

@Component({
  selector: 'app-mybookings',
  templateUrl: './mybookings.component.html',
  styleUrls: ['./mybookings.component.css'],
})
export class MybookingsComponent implements OnInit {
  constructor(
    private router: Router,
    private user: UserService,
    private carService: CarService
  ) {}
  bookingDetails: any;
  ngOnInit() {
    this.getBookings();
    if (this.router.url.includes('bookings')) {
      console.log('called');
      this.carService.rentComponent = false;
    } else {
      this.carService.rentComponent = true;
    }
  }
  ngDoCheck() {
    if (this.router.url.includes('bookings')) {
      console.log('true');
      this.carService.rentComponent = false;
    } else {
      this.carService.rentComponent = true;
    }
  }

  cancelBooking(id: number) {
    this.user.cancelBooking(id).subscribe((data) => {
      this.getBookings();
    });
  }

  getBookings() {
    this.user.getBookingDetails().subscribe((data) => {
      this.bookingDetails = data;
    });
  }
  removeUser() {
    sessionStorage.removeItem('name');
    this.router.navigate(['/home']);
  }
  bookingId:any
  setBookingId(id:any)
  {
     this.bookingId=id
  }
}
