import { Component ,Input} from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../services/user.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent {
  constructor(
    public f: FormBuilder,
    private guard: ActivatedRoute,
    private user: UserService,
    private router: Router
  ) {}
  currentpage = 'Login';

  content =
    'Sign in to your account and get the access to bookings and brouchers ';
  imgSrc = '/assets/images/securityimage3.jpg';

  ngOnInit() {}

  login = this.f.group({
    username: ['', Validators.required],
    password: ['', Validators.required],
  });

  signup = false;
  userList: any;
  valid = true;
  button ='';

  navigate() {
    this.signup = true;
    this.currentpage = 'Signup';
    this.content = 'Create the account and start up the new Journey with us';
    this.imgSrc = '/assets/images/securityimage1.jpg';
  }
  getNavigate(value: any) {
    this.signup = value;
    this.currentpage ='Login';

    this.content =
      'Sign in to your account and get the access to bookings and brouchers ';
    this.imgSrc = '/assets/images/securityimage3.jpg';
  }
  name: any | null;

  userLogin(data: any) {
    this.name = this.login.controls['username'].value;
    this.user.getUser().subscribe((userList) => {
      this.userList = userList;

      for (let user of this.userList) {
        if (
          user.username == this.login.controls['username'].value &&
          user.password == this.login.controls['password'].value
        ) {
          this.valid = true;

          sessionStorage.setItem('name', this.name);
          break;
        } else {
          this.valid = false;
        }
      }
    });
  }
   
}
