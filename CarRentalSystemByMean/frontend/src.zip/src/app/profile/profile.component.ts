import { Component, OnInit } from '@angular/core';
import { CarService } from '../services/car.service';
import { UserService } from '../services/user.service';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
})
export class ProfileComponent {
  router: any;
  userData: any;

  constructor(
    private carService: CarService,
    private user: UserService,
    private form: FormBuilder
  ) {
    this.carService.rentComponent = false;
  }

  ngOnInit() {
    this.user.getUserById().subscribe((data) => {
      this.userData = data;
      console.log(this.userData);
      this.updateUser.patchValue({
        firstname: this.userData.firstname,
        lastname: this.userData.lastname,
        mobile: this.userData.mobile,
        email: this.userData.email,
      });
    });
  }
  updateUser = this.form.group({
    firstname: ['', Validators.required],
    lastname: ['', Validators.required],
    mobile: ['', Validators.required, Validators.minLength(10)],
    email: ['', Validators.required, Validators.email],
  });

  save() {
    this.user
      .updateUserdetails(this.updateUser.value, sessionStorage.getItem('id'))
      .subscribe((data) => {});
  }
  removeUser() {
    sessionStorage.removeItem('name');
    this.router.navigate(['/home']);
  }
}
