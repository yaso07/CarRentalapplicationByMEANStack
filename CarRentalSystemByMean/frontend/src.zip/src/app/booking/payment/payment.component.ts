import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CarService } from 'src/app/services/car.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css'],
})
export class PaymentComponent {
  months = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ];
  days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  id: any;
  bookingCar: any;
  rentData: any;
  rentdate: any;
  returndate: any;
  location: any;
  totalday: any;
  time: any;
  userList:any
  cardNumber:string=''
  biddingAmount:any
  constructor(
    private route: ActivatedRoute,
    private carService: CarService,
    private router: Router,
    private user:UserService,
    private form:FormBuilder
  ) {}


  car: any;
  ngOnInit() {
    this.carService.getRentData().subscribe((data) => {
      this.rentData = data;

      this.rentdate = new Date(this.rentData.rentdate);
      this.returndate = new Date(this.rentData.returndate);
      this.location = this.rentData.location;
      console.log(this.location);
      let diff = this.returndate - this.rentdate;
      this.totalday = Math.ceil(diff / (1000 * 60 * 60 * 24));
      this.time = Math.abs(
        this.rentdate.getHours() - this.returndate.getHours()
      );
    });
    this.carService.getcardetails().subscribe((data) => {
      this.car = data;

      this.route.params.subscribe((data) => {
        this.id = data['id'];
        this.carService.currentcarid = this.id;
      });
      for (let car of this.car) {
        if (car.id == this.id) {
          this.bookingCar = car;
        }
      }

       this.user.getUserById().subscribe((data)=>
       {
            this.userList=data

       })
    });

    this.biddingAmount=sessionStorage.getItem('bidding')
  }

  payment=this.form.group({
    holderName:['',Validators.required],
    cardNumber:['',Validators.required],
    expireDate:['',Validators.required],
    cvv:['',Validators.required]


  })
value=4;
currentLength=this.cardNumber.length
  validateCard(value:HTMLInputElement)
  {


      var temp=this.currentLength





 this.currentLength = this.cardNumber.replaceAll(" ","").length;
  if(this.currentLength>temp)
  {
     this.value++;
  }
  else if(this.currentLength<=temp)
  {
    this.value--;
  }

      if (
        value.value.replaceAll(' ','').length % 4 == 0 &&
        temp <this.currentLength
      ) {
        value.value = value.value.concat(' ').toString();
      }



  }

  booking:any;
  addBooking()
  {
    let totalcost;
    if(this.biddingAmount==null)
    {
       totalcost=this.totalday * this.bookingCar.rent + 300
    }
    else
    {
      totalcost=this.biddingAmount*1+300
    }
      this.booking = {
        userId: sessionStorage.getItem('id'),
        Brand: this.bookingCar.brand,
        Model: this.bookingCar.model,
        rentDate:
          this.days[this.rentdate.getDay()] +
          ' ' +
          this.rentdate.getDate() +
          ' ' +
          this.months[this.rentdate.getMonth() ]+
          ' ',
        returnDate:
          this.days[this.returndate.getDay()] +
          ' ' +
          this.returndate.getDate() +
          ' ' +
          this.months[this.returndate.getMonth()] +
          ' ',

        location: this.location,
        totalDays: this.totalday,
        totalCost:totalcost
      };
         console.log(this.booking)
     this.user.addBooking(this.booking).subscribe((data)=>
     {
       console.log(data)
     })
  }

ngDoCheck()
{
     if (this.router.url.includes('booking')) {
       this.carService.rentComponent = false;
     } else {
       this.carService.rentComponent = true;
     }
}
}
