import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CarService } from 'src/app/services/car.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-billing',
  templateUrl: './billing.component.html',
  styleUrls: ['./billing.component.css'],
})
export class BillingComponent {
  userList: any;
  userData:any;
  existing:any;


  constructor(
    private route: ActivatedRoute,
    public carService: CarService,
    private router: Router,
    private form:FormBuilder,
    private user:UserService
  ) {}


  // ngDoCheck() {
  //   if (this.router.url.includes('booking')) {
  //     this.carService.rentComponent = false;
  //   } else {
  //     this.carService.rentComponent = true;
  //   }

  // }
  ngOnInit()
  {


       this.user.getUserByName(sessionStorage.getItem('name')).subscribe((userList) => {
       this.userList=userList;
       sessionStorage.setItem("id",this.userList[0].id)
       console.log("called")
  this.setUserData();
       
     });





  }



    billing = this.form.group({
    firstname: ['', Validators.required],
    lastname: ['', Validators.required],
    email: ['', Validators.required],
    address: ['', Validators.required],
    state: ['', Validators.required],
    pincode: ['', Validators.required],
    userid: [],
  });


addUserDetails()
{


    this.user.updateUserdetails(this.billing.value,sessionStorage.getItem('id')).subscribe((data)=>
    {

         console.log(data)
         this.billing.reset();
          this.setUserData();

         this.router.navigate(['/booking/payment/'+this.carService.currentcarid]);

    })

}




setUserData()
{
      this.user.getUserById().subscribe((data) => {
      console.log(data);
      this.userData = data;
      console.log(this.userData)
      setTimeout(() => {
      this.billing.patchValue({
        firstname: this.userData.firstname,
        lastname: this.userData.lastname,
        email: this.userData.email,
        address: this.userData.address,
        state: this.userData.state,
        pincode: this.userData.pincode,

      });
      }, 3000);

     });





}


}
