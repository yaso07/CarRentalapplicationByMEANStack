import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BillingComponent } from './booking/billing/billing.component';
import { BookingComponent } from './booking/booking.component';
import { CheckoutdetailsComponent } from './booking/checkoutdetails/checkoutdetails.component';
import { PaymentComponent } from './booking/payment/payment.component';
import { CarrentalComponent } from './carrental/carrental.component';
import { FilterComponent } from './carrental/filter/filter.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { SlideComponent } from './home/slide/slide.component';
import { InputContainerComponent } from './input-container/input-container.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { CarService } from './services/car.service';
import { FilterService } from './services/filter.service';
import { RentInputFormServiceService } from './services/rentInputFormService.service';
import { UserService } from './services/user.service';
import { ProfileComponent } from './profile/profile.component';
import { MybookingsComponent } from './mybookings/mybookings.component';
import { AdminModule } from './admin/admin.module';
import { BiddingService } from './services/bidding.service';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    SlideComponent,
    CarrentalComponent,
    LoginComponent,
    HomeComponent,
    FooterComponent,
    BookingComponent,
    BillingComponent,
    CheckoutdetailsComponent,
    PaymentComponent,
    FilterComponent,
    FooterComponent,
    InputContainerComponent,
    LoginComponent,
    SignupComponent,
    ProfileComponent,
      MybookingsComponent
   ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    
  ],

  providers:[CarService,FilterService,UserService,RentInputFormServiceService,BiddingService],
  bootstrap: [AppComponent],
})
export class AppModule {}
